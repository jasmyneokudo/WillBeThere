package com.example.willbethere;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends AppCompatActivity {

    View frameLayout;
    ImageView imageView, personImageView;
    TextView nameTextView;
    EditText nameEditText;
    int count = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.image_view);

        frameLayout = LayoutInflater.from(this).inflate(R.layout.image_design, null, false);

        frameLayout  = frameLayout.findViewById(R.id.root_layout);
        personImageView = frameLayout.findViewById(R.id.person_iv);
        nameTextView = frameLayout.findViewById(R.id.person_tv);

        nameEditText = findViewById(R.id.name_et);
    }



    public void selectImage(View view) {

        Intent photoPicker = new Intent(Intent.ACTION_PICK);
        photoPicker.setType("image/*");
        startActivityForResult(photoPicker, 0);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            final Uri imageUri = data.getData();
            try {
                final InputStream imageStream = getContentResolver().openInputStream(imageUri);
                final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);

//                personImageView.setImageBitmap(selectedImage);
//                imageView.setImageBitmap(selectedImage);
                Glide.with(this).load(imageUri).centerCrop().into(imageView);

                Glide.with(this).load(imageUri).centerCrop().into(personImageView);
                nameTextView.setText(nameEditText.getText().toString());

                Toast.makeText(this, "Tap generate to generate image", Toast.LENGTH_SHORT).show();

            } catch (FileNotFoundException e) {
                Toast.makeText(this, "Error: "+e.getMessage(), Toast.LENGTH_LONG).show();

                e.printStackTrace();
            }
        } else
            Toast.makeText(this, "No image selected", Toast.LENGTH_LONG).show();

    }

    public File saveBitmap(){

//        frameLayout.refreshDrawableState();
//        frameLayout.invalidate();

        File pictureFileDir = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "willbethere");
        if (!pictureFileDir.exists()){
            boolean isDirectoryCreated = pictureFileDir.mkdir();

            if (!isDirectoryCreated)

                Toast.makeText(this, "Cant create directory", Toast.LENGTH_SHORT).show();
            return null;
        }
//        String filename = pictureFileDir.getPath()+File.separator+System.currentTimeMillis()+".png";
        String filename = pictureFileDir.getPath()+File.separator+System.currentTimeMillis()+".png";

        File pictureFile = new File(filename);
        Bitmap bitmap = getBitmapFromView(frameLayout);
        try {
            pictureFile.createNewFile();
            FileOutputStream stream = new FileOutputStream(pictureFile);
            bitmap.compress(Bitmap.CompressFormat.PNG, 4, stream);

            stream.flush();
            stream.close();

            Toast.makeText(this, "Successful", Toast.LENGTH_SHORT).show();

        } catch(IOException ex) {
            ex.printStackTrace();
            Toast.makeText(this, "There was an issue saving the picture", Toast.LENGTH_SHORT).show();
        }
        scanGallery(pictureFile.getAbsolutePath());
        return pictureFile;

    }

    private Bitmap getBitmapFromView(View view)
    {

        frameLayout.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        frameLayout.layout(0, 0, frameLayout.getMeasuredWidth(), frameLayout.getMeasuredHeight());
        frameLayout.setDrawingCacheEnabled(true);
        frameLayout.buildDrawingCache();

        return frameLayout.getDrawingCache();
    }

    private void scanGallery(String path)
    {
        try {
            MediaScannerConnection.scanFile(this, new String[]{ path }, null, new MediaScannerConnection.OnScanCompletedListener(){

                @Override
                public void onScanCompleted(String path, Uri uri) {

                    Toast.makeText(MainActivity.this, "Found picture", Toast.LENGTH_SHORT).show();
                }
            });
        }catch(Exception ex)
        {
            ex.printStackTrace();
            Toast.makeText(this, "not found", Toast.LENGTH_SHORT).show();
        }
    }

    public void generateDesign(View view) {

        if (nameEditText.getText().toString().isEmpty())
        {
            Toast.makeText(this, "Enter name first", Toast.LENGTH_SHORT).show();
            return;
        }
        saveBitmap();
    }
}
